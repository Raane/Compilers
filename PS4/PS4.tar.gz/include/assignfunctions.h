#include "tree.h"
#include "nodetypes.h"
#include "simplifynodes.h"
#include "generator.h"

/* Assign nodes functions according to their type */
void assignFunctionsToNodes ( node_t *node );

